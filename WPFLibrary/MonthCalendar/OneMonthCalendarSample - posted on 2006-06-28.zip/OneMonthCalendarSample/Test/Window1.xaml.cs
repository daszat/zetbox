using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Globalization;
using System.Xml;
using System.Xml.XPath;
using System.Collections;
using System.Collections.ObjectModel;
using System.Windows.Shapes;

using System.Diagnostics;
using System.Reflection;


namespace MyTest
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
        }

        public void OnButtonClick(object sender, EventArgs e)
        {
        }
    }
}