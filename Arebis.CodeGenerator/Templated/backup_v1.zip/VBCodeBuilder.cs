using System;
using System.Collections.Generic;
using System.Text;

namespace Arebis.CodeGenerator.Templated
{
	public class VBCodeBuilder : ICodeBuilder
	{
		#region ICodeBuilder Members

		public Type BuildType(ITemplateInfo templateInfo)
		{
			throw new Exception("The method or operation is not implemented.");
		}

		#endregion
	}
}
