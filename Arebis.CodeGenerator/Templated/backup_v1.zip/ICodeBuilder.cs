using System;
using System.Collections.Generic;
using System.Text;

namespace Arebis.CodeGenerator.Templated
{
	public interface ICodeBuilder
	{
		Type BuildType(ITemplateInfo templateInfo);
	}
}
