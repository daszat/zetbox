using System;
using System.Collections.Generic;
using System.Text;

namespace Arebis.CodeGenerator.Templated
{
	public class ParamInfo
	{
		public ParamInfo()
		{ }

		public ParamInfo(string name, string type, string expression)
		{
			this.name = name;
			this.type = type;
			this.expression = expression;
		}

		private string name;

		public string Name
		{
			get { return name; }
			set { name = value; }
		}

		private string type;

		public string Type
		{
			get { return type; }
			set { type = value; }
		}

		private string expression;

		public string Expression
		{
			get { return expression; }
			set { expression = value; }
		}
	}
}
