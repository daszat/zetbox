using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using Arebis.CodeGeneration;
using Arebis.Parsing.MultiContent;
using System.IO;
using System.Text.RegularExpressions;
using Arebis.Utils;
using System.Collections.Specialized;

namespace Arebis.CodeGenerator.Templated
{
	public class CompiledTemplate : ITemplateInfo
	{
		#region Static fields

		public static Dictionary<string, Type> CodeBuilders;

		public static Regex RxComments = new Regex("<%--( |\\t)*\\r?\\n?(?<comment>.*)( |\\t)*\\r?\\n?--%>( |\\t)*\\r?\\n?", RegexOptions.Singleline);
		public static Regex RxIncludes = new Regex("<!--\\s*#include\\s+file\\s*=\\s*(?<quote>[\"']?)(?<filename>[^\"']*?)\\k<quote>\\s*-->( |\\t)*\\r?\\n?", RegexOptions.IgnoreCase);
		public static Regex RxDirectives = new Regex("(<%@\\s*(?<elementName>\\w+)(\\s+(?<name>\\w+)=(?<quote>[\"']?)(?<value>[^\"']*)\\k<quote>)*\\s*%>( |\\t)*\\r?\\n?)+");
		public static Regex RxScriptlets = new Regex("<%(?![@=$#%])\\s*\\r?\\n?(?<body>[^=]((.|\\r|\\n)*?(<%=(.|\\r|\\n)*?%>)?)*)%>( |\\t)*\\r?\\n?");
		public static Regex RxScripts = new Regex("<%%\\s*\\r?\\n?(?<body>((.|\\r|\\n)*?(\\w*@[^\\r\\n]*\\r?\\n)*)*)%%>( |\\t)*\\r?\\n?");
		public static string[] ExpressionTokens = new string[] { "<%=", "%>" };

		#endregion Static fields

		#region Instance fields

		// Main fields:
		private GenerationManager host;
		private FileInfo templatefileinfo;
		private MixedContentFile fileContent;
		private Type compiledTemplate = null;

		// Properties retrieved from template directives:
		private string templateLanguage;
		private string targetLanguage;
		private string description;
		private string baseClass = "Arebis.CodeGeneration.CodeTemplate";
		private List<DirectiveInfo> directives = null;
		private Dictionary<string, ReferenceInfo> references = null;
		private Dictionary<string, ImportInfo> imports = null;
		private List<ParamInfo> parameters = null;

		#endregion Instance fields

		static CompiledTemplate()
		{
			CodeBuilders = new Dictionary<string, Type>();
			CodeBuilders["VB"] = typeof(VBCodeBuilder);
			CodeBuilders["C#"] = typeof(CSCodeBuilder);
		}

		public CompiledTemplate(string filename, GenerationManager host)
		{
			this.templatefileinfo = new FileInfo(filename);
			this.host = host;
		}
		
		public void Invoke(object[] parameters)
		{
			// Create compiled type:
			if (this.compiledTemplate == null)
			{
				this.fileContent = this.ReadAndParseFile();
				this.ReadDirectives(this.fileContent);
				ICodeBuilder builder = this.CreateCodeBuilder(this.fileContent);
				this.compiledTemplate = builder.BuildType(this);
			}

			// Construct full parameters (add host):
			List<object> allparameters = new List<object>();
			allparameters.Add(this.host);
			allparameters.AddRange(parameters);

			// Create instance and invoke:
			CodeTemplate instance = (CodeTemplate)Activator.CreateInstance(this.compiledTemplate, allparameters.ToArray());
			instance.Generate();
		}

		#region ITemplateInfo Members

		IGenerationHost ITemplateInfo.Host
		{
			get { return this.host; }
		}

		NameValueCollection ITemplateInfo.Settings
		{
			get { return this.host.Settings; }
		}

		FileInfo ITemplateInfo.TemplateFileInfo
		{
			get { return this.templatefileinfo; }
		}

		MixedContentFile ITemplateInfo.FileContent
		{
			get { return this.fileContent; }
		}

		string ITemplateInfo.TemplateLanguage
		{
			get { return this.templateLanguage; }
		}

		string ITemplateInfo.TargetLanguage
		{
			get { return this.targetLanguage; }
		}

		string ITemplateInfo.Description
		{
			get { return this.description; }
		}

		string ITemplateInfo.BaseClass
		{
			get { return this.baseClass; }
		}

		IList<DirectiveInfo> ITemplateInfo.Directives
		{
			get { return this.directives; }
		}

		ICollection<ReferenceInfo> ITemplateInfo.References
		{
			get { return this.references.Values; }
		}

		ICollection<ImportInfo> ITemplateInfo.Imports
		{
			get { return this.imports.Values; }
		}

		IList<ParamInfo> ITemplateInfo.Parameters
		{
			get { return this.parameters; }
		}

		#endregion ITemplateInfo Members

		#region Private implementation

		private MixedContentFile ReadAndParseFile()
		{
			// Read the file:
			MixedContentFile file = new MixedContentFile(this.templatefileinfo.FullName, File.ReadAllText(this.templatefileinfo.FullName));

			// Process comments:
			file.ApplyParserRegex((int)TemplatePartTypes.TemplateBody, (int)TemplatePartTypes.Comment, RxComments);

			// Pre-processor 'includes':
			while (file.ApplyParserRegex((int)TemplatePartTypes.TemplateBody, (int)TemplatePartTypes.IncludePragma, RxIncludes))
			{
				foreach (ContentPart part in file.Parts)
				{
					if (part.Type == (int)TemplatePartTypes.IncludePragma)
					{
						string fn = part.Match.Groups["filename"].Value;
						fn = Path.Combine(new FileInfo(part.File.Filename).Directory.FullName, fn);
						part.Substitute(new MixedContentFile(fn, File.ReadAllText(fn)), (int)TemplatePartTypes.TemplateBody);
					}
				}
			}

			// Process declarations:
			file.ApplyParserRegex((int)TemplatePartTypes.TemplateBody, (int)TemplatePartTypes.Declaration, RxDirectives);

			// Process scripts:
			file.ApplyParserRegex((int)TemplatePartTypes.TemplateBody, (int)TemplatePartTypes.Script, RxScripts);

			// Process scriptlets:
			file.ApplyParserRegex((int)TemplatePartTypes.TemplateBody, (int)TemplatePartTypes.Scriptlet, RxScriptlets);

			return file;
		}

		private void ReadDirectives(MixedContentFile file)
		{
			// Collect directives:
			this.directives = new List<DirectiveInfo>();
			foreach (ContentPart part in file.PartsOfType((int)TemplatePartTypes.Declaration))
			{
				foreach (DirectiveInfo directive in DirectiveInfo.FromString(part.Content))
				{
					this.directives.Add(directive);
				}
			}

			// Build assembly resolution path:
			List<string> referencepathlist = this.host.ReferencePath;
			referencepathlist.Add(this.templatefileinfo.Directory.FullName);
			string[] referencepath = referencepathlist.ToArray();

			// Interpret directives:
			this.references = new Dictionary<string, ReferenceInfo>();
			this.imports = new Dictionary<string, ImportInfo>();
			this.parameters = new List<ParamInfo>();
			foreach (DirectiveInfo directive in this.directives)
			{
				if (directive.Directive == "CodeTemplate")
				{
					this.templateLanguage = directive["Language"];
					this.targetLanguage = directive["TargetLanguage"];
					this.baseClass = directive["Inherits"] ?? this.baseClass;
					this.description = directive["Description"];
				}
				else if (directive.Directive == "ReferenceAssembly")
				{
					string path = directive["Path"];
					string fullpath = FileUtils.FindInPath(path, referencepath) ?? path;
					if (fullpath != null) this.references[fullpath] = new ReferenceInfo(fullpath);
				}
				else if (directive.Directive == "Import")
				{
					string ns = directive["Namespace"];
					if (ns != null) this.imports[ns] = new ImportInfo(ns, null);
				}
				else if (directive.Directive == "Parameter")
				{
					string name = directive["Name"];
					string type = directive["Type"] ?? "System.Object";
					if (name != null) this.parameters.Add(new ParamInfo(name, type, null));
				}
			}
		}

		private ICodeBuilder CreateCodeBuilder(MixedContentFile file)
		{
			try
			{
				return (ICodeBuilder)Activator.CreateInstance(CodeBuilders[this.templateLanguage]);
			}
			catch (KeyNotFoundException)
			{
				throw new Exception(String.Format("Unknown template language '{0}'.", this.templateLanguage));
			}
		}

		#endregion Private implementation
	}
}
