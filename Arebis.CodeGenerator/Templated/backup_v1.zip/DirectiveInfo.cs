using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace Arebis.CodeGenerator.Templated
{
    public class DirectiveInfo
    {
		private static Regex directiveParser = new Regex("<%@\\s*(?<elementName>\\w+)(\\s+(?<name>\\w+)=\"(?<value>[^\"]*)\")*\\s*%>( |\\t)*\\r?\\n?");

		private string directive;
		private Dictionary<string, string> attributes;

		public static DirectiveInfo[] FromString(string directives)
		{
			List<DirectiveInfo> dirs = new List<DirectiveInfo>();
			foreach (Match match in directiveParser.Matches(directives))
			{
				dirs.Add(new DirectiveInfo(match));
			}
			return dirs.ToArray();
		}

		private DirectiveInfo(Match directiveMatch)
		{
			this.directive = directiveMatch.Groups["elementName"].Value;
			this.attributes = new Dictionary<string,string>();
			for (int i = 0; i < directiveMatch.Groups["name"].Captures.Count; i++)
            {
				this.attributes[directiveMatch.Groups["name"].Captures[i].Value] 
					= directiveMatch.Groups["value"].Captures[i].Value;
            }
		}

		public string Directive
		{
			get { return this.directive; }
		}

		public string this[string name]
		{
			get {
				if (this.attributes.ContainsKey(name))
					return this.attributes[name];
				else
					return null;
			}
		}
    }
}
