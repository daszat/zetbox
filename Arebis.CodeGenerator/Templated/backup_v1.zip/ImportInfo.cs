using System;
using System.Collections.Generic;
using System.Text;

namespace Arebis.CodeGenerator.Templated
{
	public class ImportInfo
	{
		public ImportInfo()
		{ }

		public ImportInfo(string nameSpace, string alias)
		{
			this.nameSpace = nameSpace;
			this.alias = alias;
		}

		private string nameSpace;

		public string NameSpace
		{
			get { return nameSpace; }
			set { nameSpace = value; }
		}

		private string alias;

		public string Alias
		{
			get { return alias; }
			set { alias = value; }
		}

		public bool HasAlias
		{
			get { return this.alias != null; }
		}
	}
}
