using System;
using System.Collections.Generic;
using System.Text;
using Arebis.Utils;
using Arebis.Parsing.MultiContent;
using System.IO;
using Arebis.Extensions;
using Arebis.Parsing;
using Microsoft.CSharp;
using System.CodeDom.Compiler;
using System.Text.RegularExpressions;

namespace Arebis.CodeGenerator.Templated
{
	public class CSCodeBuilder : ICodeBuilder
	{
		private static Regex RxLinesWithLinebreaks = new Regex("[^\\r\\n]*\\r?\\n?");

		private string code;

		#region ICodeBuilder Members

		public Type BuildType(ITemplateInfo templateInfo)
		{
			// Template substitution fields:
			string ns;
			string classname;
			string baseclassname;
			StringBuilder imports = new StringBuilder();
			StringBuilder fields = new StringBuilder();
			StringBuilder constructorparams = new StringBuilder();
			StringBuilder fieldinits = new StringBuilder();
			StringBuilder generatebody = new StringBuilder();
			StringBuilder scripts = new StringBuilder();

			// Base information:
			ns = "Arebis.CodeGeneration.DynamicAssemblies";
			classname = StringUtils.ToIdentifier(templateInfo.TemplateFileInfo.Name);
			baseclassname = templateInfo.BaseClass;

			// Fill imports:
			foreach(ImportInfo item in templateInfo.Imports)
			{
				imports.Append("using ");
				if (item.HasAlias)
				{
					imports.AppendLine(item.Alias);
					imports.AppendLine(" = ");
				}
				imports.Append(item.NameSpace);
				imports.AppendLine(";");
			}

			// Fill fields, fieldinits, constructorparams:
			foreach(ParamInfo item in templateInfo.Parameters)
			{
				fields.Append("\t\t");
				fields.Append("private ");
				fields.Append(item.Type);
				fields.Append(' ');
				fields.Append(item.Name);
				fields.AppendLine(";");

				fieldinits.Append("\t\t\t");
				fieldinits.Append("this.");
				fieldinits.Append(item.Name);
				fieldinits.Append(" = ");
				fieldinits.Append(item.Name);
				fieldinits.AppendLine(";");

				constructorparams.Append(", ");
				constructorparams.Append(item.Type);
				constructorparams.Append(" ");
				constructorparams.Append(item.Name);
			}

			// Fill generatebody:
			foreach (ContentPart part in templateInfo.FileContent.Parts)
			{
				// Check for TemplateBody or Scriptlet:
				if ((part.Type != (int)TemplatePartTypes.TemplateBody) && (part.Type != (int)TemplatePartTypes.Scriptlet))
					continue;

				// Add line pragma:
				generatebody.AppendLine(String.Format("#line {0} \"{1}\"", part.StartLine, new FileInfo(part.File.Filename).Name));

				// Generate:
				if (part.Type == (int)TemplatePartTypes.TemplateBody)
				{
					foreach (string line in LinesWithBreaks(part.Content))
					{
						string content = ToContent(this.LineToWriteCall(line));
						generatebody.Append("\t\t\t");
						generatebody.Append(content);
						generatebody.AppendLine();
					}
				}
				else if (part.Type == (int)TemplatePartTypes.Scriptlet)
				{
					foreach (string line in LinesWithBreaks(part.Match.Groups["body"].Value))
					{
						if (line.Trim().StartsWith("@"))
						{
							string content = ToContent(this.LineToWriteCall(line.Substring(line.IndexOf("@") + 1)));
							generatebody.Append("\t\t\t");
							generatebody.Append(content);
							generatebody.AppendLine();
						}
						else 
						{
							generatebody.Append("\t\t\t");
							generatebody.Append(line);
						}
					}
					generatebody.AppendLine();
				}
			}

			// Fill scripts:
			foreach (ContentPart part in templateInfo.FileContent.PartsOfType((int)TemplatePartTypes.Script))
			{
				// Add line pragma:
				scripts.AppendLine(String.Format("#line {0} \"{1}\"", part.StartLine, new FileInfo(part.File.Filename).Name));

				// Append script:
				scripts.AppendLine(part.Match.Groups["body"].Value);
				scripts.AppendLine();
			}


			// Build code:
			this.code = Properties.Resources.CSCodeTemplate;
			this.code = this.code.Replace("<%=imports%>", imports.ToString());
			this.code = this.code.Replace("<%=namespace%>", ns);
			this.code = this.code.Replace("<%=classname%>", classname);
			this.code = this.code.Replace("<%=baseclassname%>", baseclassname);
			this.code = this.code.Replace("<%=fields%>", fields.ToString());
			this.code = this.code.Replace("<%=constructorparameters%>", constructorparams.ToString());
			this.code = this.code.Replace("<%=fieldinitialisations%>", fieldinits.ToString());
			this.code = this.code.Replace("<%=generatebody%>", generatebody.ToString());
			this.code = this.code.Replace("<%=scripts%>", scripts.ToString());

			Console.WriteLine(code);

			
			// Compile code:

			// Collect references:
			List<string> references = new List<string>();
			foreach (ReferenceInfo item in templateInfo.References)
				references.Add(item.AssemblyName);
			references.Add(typeof(Arebis.CodeGeneration.CodeTemplate).Assembly.Location);

			foreach (string item in references)
			{
				Console.WriteLine("REF: {0}", item);
			}

			CSharpCodeProvider myCodeProvider = new CSharpCodeProvider();

			CodeDomProvider provider = CodeDomProvider.CreateProvider("c#");

			CompilerParameters pars = new CompilerParameters(references.ToArray(), StringUtils.ToIdentifier(Guid.NewGuid().ToString()), true);
			pars.GenerateExecutable = false;
			pars.GenerateInMemory = true;

			CompilerResults results = provider.CompileAssemblyFromSource(pars, this.code);

			bool hasErrors = false;
			foreach (CompilerError error in results.Errors)
			{
				if (error.IsWarning) continue;
				Console.WriteLine("Error: {0}", error.ErrorText);
				Console.WriteLine("       File {0}, line {1}", error.FileName, error.Line);
				hasErrors = true;
			}

			if (hasErrors)
			{
				throw new InvalidOperationException("Compilation had errors.");
			}

			// Return type:
			return results.CompiledAssembly.GetExportedTypes()[0];
		}

		public string Code
		{
			get { return this.code; }
		}

		#endregion

		/// <summary>
		/// Translates the string into a method call to render the line.
		/// </summary>
		public virtual string LineToWriteCall(string line)
		{ 
			StringBuilder result = new StringBuilder(line.Length * 2);

			string[] parts = StringParser.SplitByTokens(line, CompiledTemplate.ExpressionTokens, false, true, StringComparison.InvariantCulture);

			result.Append("this.WriteObjects(\"");
			bool isExpression = false;
			foreach (string part in parts)
			{
				if (isExpression)
				{
					result.Append("\", ");
					result.Append(part);
					result.Append(", \"");
				}
				else
				{
					string str = part;
					str = str.Replace("\\", "\\\\");
					str = str.Replace("\"", "\\\"");
					str = str.Replace("\r", "\\\r");
					str = str.Replace("\n", "\\\n");
					result.Append(str);
				}
				isExpression = !isExpression;
			}
			result.Append("\");");

			return result.ToString();
		}

		private static IEnumerable<string> LinesWithBreaks(string text)
		{
			List<string> lines = new List<string>();
			foreach(Match match in RxLinesWithLinebreaks.Matches(text))
			{
				string line = match.Value;
				if (line == String.Empty) break;
				lines.Add(line);
			}
			return lines;
		}

		private static string ToContent(string text)
		{
			text = text.Replace("\\\r", "\\r");
			text = text.Replace("\\\n", "\\n");
			return text;
		}
	}
}
