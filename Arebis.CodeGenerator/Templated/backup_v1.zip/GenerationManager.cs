using System;
using System.Collections.Generic;
using System.Text;
using Arebis.CodeGeneration;
using System.Collections.Specialized;
using System.Reflection;
using System.IO;

namespace Arebis.CodeGenerator.Templated
{
	public class GenerationManager : IGenerationHost
	{
		private Dictionary<string, CompiledTemplate> compiledTemplates;
		private NameValueCollection settings;
		private List<string> referencepath;

		private Stack<string> contextDirectory;
		private Stack<TextWriter> contextWriter;
		private string outputDirectory;

		public GenerationManager(NameValueCollection settings)
		{
			// Store settings:
			this.settings = settings;

			// Build base referencepath:
			this.referencepath = new List<string>();
			foreach (string item in this.Settings.GetValues("referencepath") ?? new string[0])
				this.referencepath.Add(item);
			this.referencepath.Add(new FileInfo(Assembly.GetEntryAssembly().Location).Directory.FullName);

			// Build initial context directory:
			this.contextDirectory = new Stack<string>();
			this.contextDirectory.Push(Path.Combine(Environment.CurrentDirectory, (this.Settings["sourcedir"] ?? ".")));

			// Build initial context writer:
			this.contextWriter = new Stack<TextWriter>();
			this.contextWriter.Push(new StringWriter());

			// Set output directory:
			this.outputDirectory = Path.Combine(Environment.CurrentDirectory, (this.Settings["targetdir"] ?? "."));

			// Initialize compiled templates:
			this.compiledTemplates = new Dictionary<string, CompiledTemplate>();
		}

		/// <summary>
		/// Returns a writable copy of the base reference path.
		/// </summary>
		public List<string> ReferencePath
		{
			get { return new List<string>(this.referencepath); }
		}

		public void CallTemplate(string templatefile, params object[] parameters)
		{
			// Get full template filename:
			string fulltemplatefile = Path.Combine(this.contextDirectory.Peek(), templatefile);

			// Call template:
			this.CallTemplateToContext(fulltemplatefile, parameters);
		}

		public void CallTemplateToFile(string templatefile, string outputfile, params object[] parameters)
		{
			// Get full template filename:
			string fulltemplatefile = Path.Combine(this.contextDirectory.Peek(), templatefile);

			try
			{
				// Push new writer as contexts writer:
				this.contextWriter.Push(new StringWriter());

				this.CallTemplateToContext(fulltemplatefile, parameters);
			}
			finally
			{
				// Restore previous writer context:
				TextWriter writer = this.contextWriter.Pop();

				// Write the file:
				this.WriteFile(Path.Combine(this.outputDirectory, outputfile), writer.ToString());
			}
		}

		private void CallTemplateToContext(string fulltemplatefile, params object[] parameters)
		{
			try
			{
				// Push template's directory as current directory context:
				this.contextDirectory.Push(new FileInfo(fulltemplatefile).Directory.FullName);

				// Create & cache template:
				if (this.compiledTemplates.ContainsKey(fulltemplatefile) == false)
				{
					this.compiledTemplates[fulltemplatefile] = new CompiledTemplate(fulltemplatefile, this);
				}

				// Invoke template:
				this.compiledTemplates[fulltemplatefile].Invoke(parameters);
			}
			finally
			{
				// Restore previous directory context:
				this.contextDirectory.Pop();
			}
		}

		public virtual void WriteFile(string filename, string content)
		{
			Console.WriteLine(content);
			File.WriteAllText(filename, content);
		}

		public NameValueCollection Settings
		{
			get { return this.settings; }
		}

		public void Write(string str)
		{
			this.contextWriter.Peek().Write(str);
		}

		public string NewLineString
		{
			get { return Environment.NewLine; }
		}
	}
}
