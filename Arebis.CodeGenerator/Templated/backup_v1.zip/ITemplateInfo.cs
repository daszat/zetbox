using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using Arebis.CodeGeneration;
using Arebis.Parsing.MultiContent;

namespace Arebis.CodeGenerator.Templated
{
	public interface ITemplateInfo
	{
		IGenerationHost Host { get; }
		NameValueCollection Settings { get; }
		FileInfo TemplateFileInfo { get; }
		string TemplateLanguage { get; }
		string TargetLanguage { get; }
		string Description { get; }
		string BaseClass { get; }
		IList<DirectiveInfo> Directives { get; }
		ICollection<ReferenceInfo> References { get; }
		ICollection<ImportInfo> Imports { get; }
		IList<ParamInfo> Parameters { get; }
		MixedContentFile FileContent { get; }
	}
}
