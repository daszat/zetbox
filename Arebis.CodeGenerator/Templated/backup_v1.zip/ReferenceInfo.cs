using System;
using System.Collections.Generic;
using System.Text;

namespace Arebis.CodeGenerator.Templated
{
	public class ReferenceInfo
	{
		public ReferenceInfo()
		{ }

		public ReferenceInfo(string assemblyName)
		{
			this.assemblyName = assemblyName;
		}

		private string assemblyName;

		public string AssemblyName
		{
			get { return assemblyName; }
			set { assemblyName = value; }
		}

	}
}
